import 'package:flutter/material.dart';

class CardColorModel {
	bool isSelected;
	final int cardColor;
	CardColorModel({@required this.isSelected, @required this.cardColor});
}