# Card Wallet built on Flutter

Proyecto personal para practicar Flutter y el patrón de arquitectura _Bloc_, siguiendo el tutorial en Youtube de [Daniel Ortiz](https://www.youtube.com/channel/UCkYYcjFA_G4G7qjo2jLJNpg).

En este proyecto se crea un Card Wallet para administrar las tarjetas de débito, crédito o gift card.

Interfaz Gráfica diseñada por [Caler Edwards](https://dribbble.com/shots/4536120-Manage-Cards-User-Interaction-for-Wallet-App)

![Card Wallet](https://i.imgur.com/UIr4vVw.gif)